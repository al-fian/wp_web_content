"use strict";
window.addEventListener('DOMContentLoaded', () => {
    const nameSpan = document.getElementById('name');
    const emailSpan = document.getElementById('email');
    const schoolSpan = document.getElementById('school');
    const codeSpan = document.getElementById('code');
    const instructorSpan = document.getElementById('instructor');
    const allocatedTimeSpan = document.getElementById('allocatedTime');
    const infoPreviewLogoutBtn = document.getElementById("infoPreviewLogoutBtn");
    const nextBtn = document.getElementById("nextBtn");
    window.Preload.receiveLoginSuccessfulResponse((e, allData) => {
        nameSpan.style.fontWeight = "bold";
        nameSpan.innerText = allData.studentName;
        emailSpan.style.fontWeight = "bold";
        emailSpan.innerText = allData.email;
        schoolSpan.style.fontWeight = "bold";
        schoolSpan.innerText = allData.school;
        codeSpan.style.fontWeight = "bold";
        codeSpan.innerText = allData.code;
        instructorSpan.style.fontWeight = "bold";
        instructorSpan.innerText = allData.teacherName;
        allocatedTimeSpan.style.fontWeight = "bold";
        allocatedTimeSpan.innerText = String(allData.allocatedTime) + " minutes";
        infoPreviewLogoutBtn.addEventListener("click", (e) => {
            e.preventDefault();
            window.Preload.logoutInfoPreview();
        });
        // close window === logout
        window.addEventListener('beforeunload', (e) => {
            e.preventDefault();
        });
        nextBtn.addEventListener("click", (e) => {
            e.preventDefault();
            window.Preload.openWritingWindow();
        });
    });
});
//# sourceMappingURL=preview.renderer.js.map