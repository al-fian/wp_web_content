declare function validateEmail(email: string): boolean;
declare function validatePassword(password: string): boolean;
