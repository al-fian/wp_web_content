"use strict";
window.addEventListener('DOMContentLoaded', () => {
    window.Preload.receiveDataForWritingWindow((e, data) => {
        const studentSpan = document.getElementById('studentSpan');
        const emailSpan = document.getElementById('emailSpan');
        const schoolSpan = document.getElementById('schoolSpan');
        const codeSpan = document.getElementById('codeSpan');
        const subjectSpan = document.getElementById('subjectSpan');
        const instructorSpan = document.getElementById('instructorSpan');
        const startTime = document.getElementById('startTime');
        const startDate = document.getElementById('startDate');
        const allocatedTime = document.getElementById('allocatedTime');
        studentSpan.textContent = data.studentName;
        emailSpan.textContent = data.email;
        schoolSpan.textContent = data.school;
        codeSpan.textContent = data.code;
        subjectSpan.textContent = data.subject;
        instructorSpan.textContent = data.teacherName;
        // local time & date
        const date = new Date(data.answerStartAt);
        startTime.textContent = date.toLocaleTimeString();
        startDate.textContent = date.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        allocatedTime.textContent = String(data.allocatedTime);
        // question modal
        // three classes of closeX
        const spanX = document.getElementsByClassName("closeX");
        // show Question Modal
        const questionPanel = document.getElementById("questionPanel");
        questionPanel.textContent = data.questionBody;
        const questionBtn = document.getElementById("showQuestion");
        const questionModal = document.getElementById("questionModal");
        questionBtn.addEventListener("click", () => {
            questionModal.style.display = "block";
        });
        // clicks on <span> (x), closes the modal
        spanX[0].addEventListener("click", () => {
            questionModal.style.display = "none";
        });
        // clicks anywhere outside modal, closes it
        window.addEventListener("click", (e) => {
            if (e.target == questionModal) {
                questionModal.style.display = "none";
            }
        });
        // show Logout modal
        const logoutBtn = document.getElementById("logoutBtn");
        const logoutModal = document.getElementById("logoutModal");
        logoutBtn.addEventListener("click", () => {
            logoutModal.style.display = "block";
        });
        spanX[1].addEventListener("click", () => {
            logoutModal.style.display = "none";
        });
        const cancelLogoutBtn = document.getElementById('cancelLogout');
        cancelLogoutBtn.addEventListener('click', () => {
            logoutModal.style.display = "none";
        });
        const logoutAnywayBtn = document.getElementById('logoutAnyway');
        const thanksModal = document.getElementById('thanksModal');
        logoutAnywayBtn.addEventListener('click', () => {
            logoutModal.style.display = "none";
            thanksModal.style.display = "block";
            setTimeout(() => {
                window.Preload.logoutWritingWindow(writingTextarea.value);
            }, 8000);
        });
        window.addEventListener('click', (event) => {
            if (event.target == logoutModal) {
                logoutModal.style.display = "none";
            }
        });
        // Countdown allocated time
        const aTimeInMiliseconds = data.allocatedTime * 60 * 1000;
        const countDownTime = Date.now() + aTimeInMiliseconds;
        function fiveMinuteWarning() {
            const fiveMinuteModal = document.getElementById("fiveMinuteModal");
            fiveMinuteModal.style.display = "block";
            spanX[2].addEventListener("click", () => {
                fiveMinuteModal.style.display = "none";
            });
            window.addEventListener("click", (e) => {
                if (e.target == fiveMinuteModal) {
                    fiveMinuteModal.style.display = "none";
                }
            });
            setTimeout(() => {
                fiveMinuteModal.style.display = "none";
            }, 10000);
        }
        // Update the count down every 1 second
        let remainingTimeSpan = document.getElementById("remainingTime");
        let remainingTimeSpanOnModal = document.getElementById("remainingTimeOnModal");
        let remainingTimeSpanOnSwitchAwayModal = document.getElementById("remainingTimeOnSwitchAwayModal");
        let countdownOnTimeOutModal = document.getElementById("timeOutCountdown");
        let timeoutOnThanksModal = document.getElementById("timeoutOnThanksModal");
        let timeoutOnThanksModal5Second = 8000;
        let x = setInterval(function () {
            const now = Date.now();
            const distance = countDownTime - now; // miliseconds
            // Time calculations for days, hours, minutes and seconds
            let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            let seconds = Math.floor((distance % (1000 * 60)) / 1000);
            if (thanksModal.style.display === "block") {
                timeoutOnThanksModal5Second = timeoutOnThanksModal5Second - 1000;
                let timeout5seconds = Math.floor((timeoutOnThanksModal5Second / 1000));
                timeoutOnThanksModal.textContent = `${timeout5seconds}`;
            }
            // display hours, minutes, seconds
            if (hours === 0 && minutes === 0) {
                remainingTimeSpan.textContent = `00:00:${seconds < 10 ? '0' : ''}${seconds}`;
                remainingTimeSpanOnModal.textContent = `00:00:${seconds < 10 ? '0' : ''}${seconds}`;
                remainingTimeSpanOnSwitchAwayModal.textContent = `00:00:${seconds < 10 ? '0' : ''}${seconds}`;
                remainingTimeSpan.classList.remove("teal-text", "text-teal");
                remainingTimeSpan.classList.add("pink-text", "text-pink-darken-3");
                remainingTimeSpanOnModal.classList.remove("teal-text", "text-teal");
                remainingTimeSpanOnModal.classList.add("pink-text", "text-pink-darken-3");
                remainingTimeSpanOnSwitchAwayModal.classList.remove("teal-text", "text-teal");
                remainingTimeSpanOnSwitchAwayModal.classList.add("pink-text", "text-pink-darken-3");
            }
            else if (hours === 0) {
                remainingTimeSpan.textContent = `00:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
                remainingTimeSpanOnModal.textContent = `00:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
                remainingTimeSpanOnSwitchAwayModal.textContent = `00:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
                if (minutes < 5) {
                    remainingTimeSpan.classList.remove("teal-text", "text-teal");
                    remainingTimeSpan.classList.add("pink-text", "text-pink-darken-3");
                    remainingTimeSpanOnModal.classList.remove("teal-text", "text-teal");
                    remainingTimeSpanOnModal.classList.add("pink-text", "text-pink-darken-3");
                    remainingTimeSpanOnSwitchAwayModal.classList.remove("teal-text", "text-teal");
                    remainingTimeSpanOnSwitchAwayModal.classList.add("pink-text", "text-pink-darken-3");
                }
            }
            else {
                remainingTimeSpan.textContent = `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
                remainingTimeSpanOnModal.textContent = `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
                remainingTimeSpanOnSwitchAwayModal.textContent = `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
            }
            // When 5 minutes more remains: 0 hours, 6 minutes, 0 seconds in string
            if (`${hours}${minutes}${seconds}` === '050') {
                fiveMinuteWarning();
            }
            // If count down over
            if (distance < 0) {
                clearInterval(x);
                remainingTimeSpan.textContent = "Time Out";
                const timeOutModal = document.getElementById('timeOutModal');
                timeOutModal.style.display = "block";
                if (timeOutModal.style.display === "block") {
                    setInterval(() => {
                        timeoutOnThanksModal5Second = timeoutOnThanksModal5Second - 1000;
                        let timeout5seconds = Math.floor((timeoutOnThanksModal5Second / 1000));
                        countdownOnTimeOutModal.textContent = `${timeout5seconds}`;
                    }, 1000);
                }
                setTimeout(() => {
                    window.Preload.logoutTimeOut(writingTextarea.value);
                }, 8000);
            }
        }, 1000);
        // Counting words, sentences, paragraphs
        const paragraphTotalSpan = document.getElementById("paragraphTotal");
        const sentenceTotalSpan = document.getElementById("sentenceTotal");
        const wordTotalSpan = document.getElementById("wordTotal");
        const writingTextarea = document.getElementById("writingTextarea");
        writingTextarea.value = data.answerBody;
        CountWords(writingTextarea.value);
        writingTextarea.addEventListener("input", () => {
            CountWords(writingTextarea.value);
        });
        function CountWords(stringValue) {
            let original = stringValue;
            // strip tags
            original = original.replace(/<\/?[a-z][^>]*>/gi, '');
            const trimmed = original.trim();
            const paragraphTotal = trimmed ? (trimmed.match(/\n{2,}/g) || []).length + 1 : 0;
            paragraphTotalSpan.textContent = String(paragraphTotal);
            const sentenceTotal = trimmed ? (trimmed.match(/[\w|\)][.?!](\s|$)/g) || []).length : 0;
            sentenceTotalSpan.textContent = String(sentenceTotal);
            const wordTotal = trimmed ? (trimmed.replace(/['";:,.?¿\-!¡]+/g, '').match(/\S+/g) || []).length : 0;
            wordTotalSpan.textContent = String(wordTotal);
        }
        // limited editing functions: copy, paste, cut, undo, redo
        let textStore = {
            copied: "",
            undo: "",
            redo: "",
            selectionStart: 0,
            selectionEnd: 0
        };
        const copyTxt = document.getElementById("copyTxt");
        const pasteTxt = document.getElementById("pasteTxt");
        const cutTxt = document.getElementById("cutTxt");
        const undoTxt = document.getElementById("undoTxt");
        const redoTxt = document.getElementById("redoTxt");
        copyTxt.addEventListener("click", () => {
            const selectedText = document.getSelection().toString();
            textStore.copied = selectedText;
        });
        pasteTxt.addEventListener("click", () => {
            writingTextarea.focus();
            textStore.undo = writingTextarea.value;
            writingTextarea.setRangeText(textStore.copied, writingTextarea.selectionStart, writingTextarea.selectionEnd, "end");
            textStore.selectionStart = writingTextarea.selectionStart;
            textStore.selectionEnd = writingTextarea.selectionEnd;
        });
        cutTxt.addEventListener("click", () => {
            writingTextarea.focus();
            textStore.copied = document.getSelection().toString();
            textStore.selectionStart = writingTextarea.selectionStart;
            textStore.selectionEnd = writingTextarea.selectionEnd;
            textStore.undo = writingTextarea.value;
            writingTextarea.setRangeText("");
        });
        undoTxt.addEventListener("click", () => {
            writingTextarea.focus();
            textStore.redo = writingTextarea.value;
            writingTextarea.focus();
            writingTextarea.value = textStore.undo;
            if (textStore.selectionStart && textStore.selectionEnd) {
                writingTextarea.setSelectionRange(textStore.selectionStart, textStore.selectionEnd);
            }
        });
        redoTxt.addEventListener("click", () => {
            if (textStore.redo) {
                textStore.undo = writingTextarea.value;
                writingTextarea.focus();
                writingTextarea.value = textStore.redo;
            }
        });
        // Blur -> when switching away without loggging out
        const switchAwayModal = document.getElementById("switchAwayModal");
        window.addEventListener("blur", (e) => {
            e.stopImmediatePropagation();
            e.preventDefault();
            switchAwayModal.style.display = "block";
        });
        const cancelSwitchAwayBtn = document.getElementById('cancelSwitchAwayBtn');
        cancelSwitchAwayBtn.addEventListener('click', () => {
            switchAwayModal.style.display = "none";
        });
        const logoutSwitchAwayBtn = document.getElementById('logoutSwitchAwayBtn');
        logoutSwitchAwayBtn.addEventListener('click', () => {
            switchAwayModal.style.display = "none";
            thanksModal.style.display = "block";
            setTimeout(() => {
                window.Preload.logoutWritingWindow(writingTextarea.value);
            }, 8000);
        });
        spanX[3].addEventListener("click", () => {
            switchAwayModal.style.display = "none";
        });
    }); // receiveDataForWritingWindow
    // disable right mouse-click
    document.addEventListener('contextmenu', event => {
        event.preventDefault();
        return false;
    });
    document.addEventListener('keydown', event => {
        // Do nothing if the event was already processed
        if (event.defaultPrevented) {
            return;
        }
        let capturedKey = event.key;
        // disable F12 key
        if (capturedKey == "F12") {
            return false;
        }
        // disable Ctrl+Shift+i
        if (event.ctrlKey && event.shiftKey && capturedKey == "i") {
            return false;
        }
        // disable Ctrl+Shift+j
        if (event.ctrlKey && event.shiftKey && capturedKey == "j") {
            return false;
        }
        // disable Ctrl+u
        if (event.ctrlKey && capturedKey == "u") {
            return false;
        }
    });
    // const logoutBtn = document.getElementById("logoutBtn") as HTMLButtonElement;
    // logoutBtn.addEventListener("click", () => window.close());
});
//# sourceMappingURL=writing.renderer.js.map