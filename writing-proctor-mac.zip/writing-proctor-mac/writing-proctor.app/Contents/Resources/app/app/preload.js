"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
electron_1.contextBridge.exposeInMainWorld('Preload', {
    login: (loginInput) => electron_1.ipcRenderer.send("login-to-preview", loginInput),
    receiveLoginErrorResponse: (callback) => {
        electron_1.ipcRenderer.on("login-error", callback);
    },
    receiveLoginSuccessfulResponse: (callback) => {
        electron_1.ipcRenderer.on("login-to-preview", callback);
    },
    verifyCode: (codeValue) => electron_1.ipcRenderer.send('verify-code', codeValue),
    isCodeValid: (callback) => {
        electron_1.ipcRenderer.on('valid-code', callback);
    },
    isCodeInvalid: (callback) => {
        electron_1.ipcRenderer.on('invalid-code', callback);
    },
    logoutInfoPreview: () => electron_1.ipcRenderer.send("info-preview-logout"),
    openWritingWindow: () => electron_1.ipcRenderer.send("open-writing-window"),
    receiveDataForWritingWindow: (callback) => {
        electron_1.ipcRenderer.on("open-writing-window", callback);
    },
    logoutWritingWindow: (AnswerBody) => electron_1.ipcRenderer.send("writing-window-logout", AnswerBody),
    logoutTimeOut: (AnswerBody) => electron_1.ipcRenderer.send("time-out-logout", AnswerBody)
});
//# sourceMappingURL=preload.js.map