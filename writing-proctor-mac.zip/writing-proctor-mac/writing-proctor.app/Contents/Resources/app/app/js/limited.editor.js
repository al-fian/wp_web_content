// limited editing functions
const store = {};
const writingTextarea = document.getElementById('writingTextarea')

function copyTxt() {
    const selectedText = document.getSelection().toString();
    store.copied = "";
    store.copied = selectedText;
}

function pasteTxt() {
    writingTextarea.focus();
    store.undo = "";
    store.undo = writingTextarea.value;    
    writingTextarea.setRangeText(store.copied, writingTextarea.selectionStart,writingTextarea.selectionEnd,"end");
    store.selectionStart = writingTextarea.selectionStart;
    store.selectionEnd = writingTextarea.selectionEnd;
}

function cutTxt() {
    writingTextarea.focus();
    store.copied = "";
    store.copied = document.getSelection().toString();
    store.undo = "";
    store.selectionStart = writingTextarea.selectionStart;
    store.selectionEnd = writingTextarea.selectionEnd;
    store.undo = writingTextarea.value;
    writingTextarea.setRangeText("");
}

function undoTxt() {
    writingTextarea.focus();
    store.redo = writingTextarea.value;
    writingTextarea.focus();
    writingTextarea.value = store.undo;

    if (store.selectionStart && store.selectionEnd)
    {
        writingTextarea.setSelectionRange(store.selectionStart,store.selectionEnd);
    }
}

function redoTxt() {

    if (store.redo)
    {
        store.undo = writingTextarea.value;
        writingTextarea.focus();
        writingTextarea.value = store.redo;
    }

}

