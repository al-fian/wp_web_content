"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path = __importStar(require("path"));
// url endpoint
const urlWp = "https://wp.sixtypress.com/api/incomings";
// Set env
// process.env.NODE_ENV = 'production';
// process.env.NODE_ENV = 'development';
// const isDev = process.env.NODE_ENV !== 'production' ? true : false;
const isMac = process.platform === 'darwin' ? true : false;
const axios_1 = __importDefault(require("axios"));
const iconLink = `${__dirname}/assets/icons/Icon_256x256.png`;
const windowHeight = 600;
let loginWindow;
let previewWindow;
let writingWindow;
// data persistence
let allData = {
    token: "",
    student: {
        id: "",
        name: "",
        email: "",
        school: ""
    },
    question: {
        id: "",
        code: "",
        subject: "",
        questionBody: "",
        allocatedTime: 60,
        teacherName: "",
    },
    openInfoPreview: {
        infoPreviewAccessId: "",
        inforPreviewAccessLoginAt: new Date()
    },
    reportId: "",
    writingWindowAccessId: "",
    answerStartAt: new Date(),
    answerBody: "",
    answerId: ""
};
let closeFlag = {
    isWindowAppCloseBtnClicked: true
};
function createLoginWindow() {
    loginWindow = new electron_1.BrowserWindow({
        icon: iconLink,
        width: 400,
        height: windowHeight,
        resizable: false,
        webPreferences: {
            preload: path.join(__dirname, "app", "preload.js")
        }
    });
    loginWindow.loadFile(path.join(__dirname, "app", "login-window.html"));
    electron_1.app.whenReady().then(() => {
        if (loginWindow != null) {
            loginWindow.on("close", () => loginWindow = null);
        }
    });
}
function createPreviewWindow() {
    previewWindow = new electron_1.BrowserWindow({
        icon: iconLink,
        width: 800,
        height: windowHeight,
        resizable: false,
        webPreferences: {
            preload: path.join(__dirname, "app", "preload.js")
        }
    });
    previewWindow.loadFile(path.join(__dirname, "app", "preview-window.html"));
    electron_1.app.whenReady().then(() => {
        if (previewWindow != null) {
            previewWindow.on('close', () => {
                if (closeFlag.isWindowAppCloseBtnClicked === false) {
                    previewWindow = null;
                    return;
                }
                if (closeFlag.isWindowAppCloseBtnClicked === true) {
                    (0, axios_1.default)({
                        method: "post",
                        url: `${urlWp}/info-preview-logout`,
                        data: { InfoPreviewAccessId: allData.openInfoPreview.infoPreviewAccessId, ReportId: allData.reportId },
                        headers: { Authorization: `Bearer ${allData.token}` }
                    }).then((res) => {
                        if (res.data.isLogoutDone === true) {
                            if (previewWindow != null) {
                                previewWindow = null;
                                return;
                            }
                        }
                    }).catch((error) => {
                        console.log("Error message: ", error.message);
                    });
                }
            });
        }
    });
}
function createWritingWindow() {
    writingWindow = new electron_1.BrowserWindow({
        icon: iconLink,
        kiosk: true,
        show: false,
        resizable: false,
        fullscreen: true,
        webPreferences: {
            preload: path.join(__dirname, "app", "preload.js")
        }
    });
    writingWindow.loadFile(path.join(__dirname, "app", "writing-window.html"));
    writingWindow.once("ready-to-show", () => {
        if (writingWindow != null) {
            writingWindow.show();
        }
    });
    electron_1.app.whenReady().then(() => {
        if (writingWindow != null) {
            writingWindow.on('close', () => {
                if (closeFlag.isWindowAppCloseBtnClicked === false) {
                    writingWindow = null;
                    return;
                }
                if (closeFlag.isWindowAppCloseBtnClicked === true) {
                    (0, axios_1.default)({
                        method: "post",
                        url: `${urlWp}/writing-window-logout`,
                        data: {
                            AnswerId: allData.answerId,
                            WritingWindowAccessId: allData.writingWindowAccessId,
                            ReportId: allData.reportId,
                            StudentId: allData.student.id,
                            Code: allData.question.code,
                            AnswerBody: allData.answerBody,
                        },
                        headers: { Authorization: `Bearer ${allData.token}` }
                    }).then((res) => {
                        if (res.data.isLogoutDone === true) {
                            if (writingWindow != null) {
                                writingWindow = null;
                                return;
                            }
                        }
                    }).catch((error) => {
                        console.log("Error message: ", error.message);
                    });
                }
            });
        }
    });
}
electron_1.app.whenReady().then(() => {
    createLoginWindow();
    electron_1.app.on("activate", function () {
        if (electron_1.BrowserWindow.getAllWindows().length === 0)
            createLoginWindow();
    });
});
// Menu
const menuTemplate = [
    ...(isMac ? [{
            label: electron_1.app.name
        }] : [])
];
const menu = electron_1.Menu.buildFromTemplate(menuTemplate);
electron_1.Menu.setApplicationMenu(menu);
electron_1.ipcMain.on("login-to-preview", (e, args) => {
    e.preventDefault();
    (0, axios_1.default)({
        method: "post",
        url: `${urlWp}/login`,
        data: { Code: args.code, Email: args.email, Password: args.password }
    }).then((res) => {
        allData.token = res.data.token;
        allData.student.id = res.data.studentDto.id;
        allData.student.name = res.data.studentDto.name;
        allData.student.email = res.data.studentDto.email;
        allData.student.school = res.data.studentDto.school;
        allData.question.id = res.data.questionDto.id;
        allData.question.code = res.data.questionDto.code;
        allData.question.subject = res.data.questionDto.subject;
        allData.question.questionBody = res.data.questionDto.questionBody;
        allData.question.allocatedTime = res.data.questionDto.allocatedTime;
        allData.question.teacherName = res.data.questionDto.teacherName;
        allData.openInfoPreview.infoPreviewAccessId = res.data.openInfoPreviewDto.infoPreviewAccessId;
        allData.openInfoPreview.inforPreviewAccessLoginAt = res.data.openInfoPreviewDto.inforPreviewAccessLoginAt;
        allData.reportId = res.data.reportDto.id;
        const allDataForPreview = {
            studentName: res.data.studentDto.name,
            email: res.data.studentDto.email,
            school: res.data.studentDto.school,
            code: res.data.questionDto.code,
            allocatedTime: res.data.questionDto.allocatedTime,
            teacherName: res.data.questionDto.teacherName
        };
        createPreviewWindow();
        if (previewWindow != null) {
            previewWindow.webContents.on("did-finish-load", () => {
                previewWindow?.webContents.send("login-to-preview", allDataForPreview);
            });
        }
        if (loginWindow != null) {
            loginWindow.close();
        }
    }).catch((error) => {
        const errorStatus = error.response?.status;
        if (loginWindow != null) {
            loginWindow.webContents.send("login-error", errorStatus);
        }
    });
});
electron_1.ipcMain.on("verify-code", (e, arg) => {
    e.preventDefault();
    (0, axios_1.default)({
        method: "post",
        url: `${urlWp}/check-code`,
        data: { Code: arg }
    }).then((res) => {
        const successStatus = res.status;
        if (loginWindow != null) {
            loginWindow.webContents.send("valid-code", successStatus);
        }
    }).catch((error) => {
        const errorStatus = error.response?.status;
        if (loginWindow != null) {
            loginWindow.webContents.send("invalid-code", errorStatus);
        }
    });
});
electron_1.ipcMain.on("info-preview-logout", (e) => {
    e.preventDefault();
    (0, axios_1.default)({
        method: "post",
        url: `${urlWp}/info-preview-logout`,
        data: { InfoPreviewAccessId: allData.openInfoPreview.infoPreviewAccessId, ReportId: allData.reportId },
        headers: { Authorization: `Bearer ${allData.token}` }
    }).then((res) => {
        if (res.data.isLogoutDone === true) {
            if (previewWindow != null) {
                closeFlag.isWindowAppCloseBtnClicked = false;
                previewWindow.close();
            }
        }
    }).catch((error) => {
        console.log("Error message: ", error.message);
    });
});
electron_1.ipcMain.on("open-writing-window", (e) => {
    e.preventDefault();
    (0, axios_1.default)({
        method: "post",
        url: `${urlWp}/writing-window`,
        data: {
            StudentId: allData.student.id,
            Code: allData.question.code,
            InfoPreviewAccessLoginAt: allData.openInfoPreview.inforPreviewAccessLoginAt,
            QuestionId: allData.question.id,
            ReportId: allData.reportId
        },
        headers: { Authorization: `Bearer ${allData.token}` }
    }).then((res) => {
        allData.answerId = res.data.answerId;
        allData.answerBody = res.data.answerBody;
        allData.answerStartAt = res.data.answerStartAt;
        allData.writingWindowAccessId = res.data.writingWindowAccessId;
        const allDataForWritingWindow = {
            answerStartAt: res.data.answerStartAt,
            answerBody: res.data.answerBody,
            studentName: allData.student.name,
            email: allData.student.email,
            school: allData.student.school,
            code: allData.question.code,
            subject: allData.question.subject,
            questionBody: allData.question.questionBody,
            allocatedTime: allData.question.allocatedTime,
            teacherName: allData.question.teacherName,
        };
        // console.log("Data for Writing Window: ", allDataForWritingWindow);
        createWritingWindow();
        if (writingWindow != null) {
            writingWindow.webContents.on("did-finish-load", () => {
                writingWindow?.webContents.send("open-writing-window", allDataForWritingWindow);
            });
            // console.log("Data for Writing Window: ", allDataForWritingWindow);
        }
        if (previewWindow != null) {
            previewWindow.close();
        }
    }).catch((error) => {
        console.log("Error message: ", error.message);
    });
});
electron_1.ipcMain.on("writing-window-logout", (e, AnswerBody) => {
    e.preventDefault();
    allData.answerBody = AnswerBody;
    (0, axios_1.default)({
        method: "post",
        url: `${urlWp}/writing-window-logout`,
        data: {
            AnswerId: allData.answerId,
            WritingWindowAccessId: allData.writingWindowAccessId,
            ReportId: allData.reportId,
            StudentId: allData.student.id,
            Code: allData.question.code,
            AnswerBody: AnswerBody,
        },
        headers: { Authorization: `Bearer ${allData.token}` }
    }).then((res) => {
        if (res.data.isLogoutDone === true) {
            if (writingWindow != null) {
                closeFlag.isWindowAppCloseBtnClicked = false;
                writingWindow.close();
            }
        }
    }).catch((error) => {
        console.log("Error message: ", error.message);
    });
});
electron_1.ipcMain.on("time-out-logout", (e, AnswerBody) => {
    e.preventDefault();
    allData.answerBody = AnswerBody;
    (0, axios_1.default)({
        method: "post",
        url: `${urlWp}/time-out-logout`,
        data: {
            AnswerId: allData.answerId,
            WritingWindowAccessId: allData.writingWindowAccessId,
            ReportId: allData.reportId,
            StudentId: allData.student.id,
            Code: allData.question.code,
            AnswerBody: AnswerBody,
        },
        headers: { Authorization: `Bearer ${allData.token}` }
    }).then((res) => {
        if (res.data.isLogoutDone === true) {
            if (writingWindow != null) {
                closeFlag.isWindowAppCloseBtnClicked = false;
                writingWindow.close();
            }
        }
    }).catch((error) => {
        console.log("Error message: ", error.message);
    });
});
electron_1.app.on("window-all-closed", function () {
    if (!isMac)
        electron_1.app.quit();
});
//# sourceMappingURL=main.js.map