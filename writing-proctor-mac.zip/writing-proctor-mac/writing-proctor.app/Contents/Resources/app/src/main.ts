import {app, ipcMain, BrowserWindow, Menu, screen} from 'electron';
import * as path from "path";

// url endpoint
const urlWp = "https://wp.sixtypress.com/api/incomings";

// Set env
// process.env.NODE_ENV = 'production';
// process.env.NODE_ENV = 'development';

// const isDev = process.env.NODE_ENV !== 'production' ? true : false;
const isMac = process.platform === 'darwin' ? true : false;

import axios, {AxiosResponse, AxiosError} from "axios";

const iconLink: string = `${__dirname}/assets/icons/Icon_256x256.png`;

const windowHeight:number = 600;

let loginWindow: BrowserWindow | null;
let previewWindow: BrowserWindow | null;
let writingWindow: BrowserWindow | null;

// data persistence
let allData:IAllData = {
  token: "",
  student: {
    id: "",
    name: "",
    email: "",
    school: ""
  },
  question: {
    id: "",
    code: "",
    subject: "",
    questionBody: "",
    allocatedTime: 60,
    teacherName: "",
  },
  openInfoPreview: {
    infoPreviewAccessId: "",
    inforPreviewAccessLoginAt: new Date()
  },
  reportId: "",
  writingWindowAccessId:"",
  answerStartAt:new Date(),
  answerBody:"",
  answerId:""
};

let closeFlag:ICloseFlag  = {
  isWindowAppCloseBtnClicked: true
}

function createLoginWindow () {
  loginWindow = new BrowserWindow({
      icon: iconLink,
      width: 400,
      height: windowHeight,
      resizable: false,
      webPreferences: {
        preload: path.join(__dirname, "app", "preload.js")
      }
  });

  loginWindow.loadFile(path.join(__dirname, "app", "login-window.html"));

  app.whenReady().then(() => {
    if (loginWindow != null){
      loginWindow.on("close", () => loginWindow = null);
    }
  });
}

function createPreviewWindow () {
  previewWindow = new BrowserWindow({
      icon: iconLink,
      width: 800,
      height: windowHeight,
      resizable: false,
      webPreferences: {
        preload: path.join(__dirname, "app", "preload.js")
      }
  });
  
  previewWindow.loadFile(path.join(__dirname, "app", "preview-window.html"));

  app.whenReady().then(() => {
    if (previewWindow != null){

      previewWindow.on('close', () => { 

        if (closeFlag.isWindowAppCloseBtnClicked === false) {
          previewWindow = null;
          return;
        }

        if (closeFlag.isWindowAppCloseBtnClicked === true) {

            axios({
              method: "post",
              url: `${urlWp}/info-preview-logout`,
              data: { InfoPreviewAccessId: allData.openInfoPreview.infoPreviewAccessId, ReportId:allData.reportId },
              headers: { Authorization: `Bearer ${allData.token}` }
            }).then((res:AxiosResponse) => {

              if (res.data.isLogoutDone === true) {
          
                if (previewWindow != null)
                {
                  previewWindow = null;
                  return;
                }
              }    
          
            }).catch((error:AxiosError) => {
          
              console.log("Error message: ", error.message);
          
            });

        }

      });
      
    }
  });
}

function createWritingWindow() {
  writingWindow = new BrowserWindow({
    icon: iconLink,
    kiosk: true,
    show: false,
    resizable: false,
    fullscreen: true,
    webPreferences: {
      preload: path.join(__dirname, "app", "preload.js")
    }
  });

  writingWindow.loadFile(path.join(__dirname, "app", "writing-window.html"));

  writingWindow.once("ready-to-show", () => {

    if (writingWindow != null)
    {
      writingWindow.show();  
    }
  });

  app.whenReady().then(() => {
    if (writingWindow != null){

      writingWindow.on('close', () => { 

        if (closeFlag.isWindowAppCloseBtnClicked === false) {
          writingWindow = null;
          return;
        }

        if (closeFlag.isWindowAppCloseBtnClicked === true) {

            axios({
              method: "post",
              url: `${urlWp}/writing-window-logout`,
              data: { 
                AnswerId:allData.answerId,
                WritingWindowAccessId:allData.writingWindowAccessId,
                ReportId:allData.reportId,
                StudentId:allData.student.id,
                Code:allData.question.code, 
                AnswerBody:allData.answerBody,
              },
              headers: { Authorization: `Bearer ${allData.token}` }
            }).then((res:AxiosResponse) => {
          
              if (res.data.isLogoutDone === true) {
          
                if (writingWindow != null)
                {
                  writingWindow = null;
                  return;
                }
              }  
          
            }).catch((error:AxiosError) => {
          
              console.log("Error message: ", error.message);
          
            });

        }

      });
      
    }
  });
}

app.whenReady().then(() => {
  createLoginWindow();
  
  app.on("activate", function () {
    if (BrowserWindow.getAllWindows().length === 0) createLoginWindow();
  });
});

// Menu
const menuTemplate = [
  ...(isMac ? [{
      label: app.name
  }] : [])
];

const menu = Menu.buildFromTemplate(menuTemplate);
Menu.setApplicationMenu(menu);

ipcMain.on("login-to-preview", (e:Event, args:ILoginInput) => {
  e.preventDefault();

  axios({
    method: "post",
    url: `${urlWp}/login`,
    data: {Code:args.code,Email:args.email,Password:args.password}
  }).then((res:AxiosResponse) => {

    allData.token = res.data.token;
    allData.student.id = res.data.studentDto.id;
    allData.student.name = res.data.studentDto.name;
    allData.student.email = res.data.studentDto.email;
    allData.student.school = res.data.studentDto.school;
    allData.question.id = res.data.questionDto.id;
    allData.question.code = res.data.questionDto.code;
    allData.question.subject = res.data.questionDto.subject;
    allData.question.questionBody = res.data.questionDto.questionBody;
    allData.question.allocatedTime = res.data.questionDto.allocatedTime;
    allData.question.teacherName = res.data.questionDto.teacherName;
    allData.openInfoPreview.infoPreviewAccessId = res.data.openInfoPreviewDto.infoPreviewAccessId;
    allData.openInfoPreview.inforPreviewAccessLoginAt = res.data.openInfoPreviewDto.inforPreviewAccessLoginAt;
    allData.reportId = res.data.reportDto.id;

    const allDataForPreview:IAllDataForPreview = {
      studentName:res.data.studentDto.name,
      email:res.data.studentDto.email,
      school:res.data.studentDto.school,
      code:res.data.questionDto.code,
      allocatedTime:res.data.questionDto.allocatedTime,
      teacherName:res.data.questionDto.teacherName
    }

    createPreviewWindow();
  
    if (previewWindow != null)
    {
      previewWindow.webContents.on("did-finish-load", ()=>{
        previewWindow?.webContents.send("login-to-preview", allDataForPreview);
      });
    }

    if (loginWindow != null)
    {
      loginWindow.close();
    }

  }).catch((error:AxiosError) => {

    const errorStatus:number | undefined = error.response?.status;

    if (loginWindow != null)
    {
      loginWindow.webContents.send("login-error", errorStatus);
    }

  });

});

ipcMain.on("verify-code", (e:Event, arg:string) => {
  e.preventDefault();

  axios({
    method: "post",
    url: `${urlWp}/check-code`,
    data: {Code:arg}
  }).then((res:AxiosResponse) => {

    const successStatus:number = res.status;

    if (loginWindow != null)
    {
      loginWindow.webContents.send("valid-code", successStatus);
    }

  }).catch((error:AxiosError) => {

    const errorStatus:number | undefined = error.response?.status;

    if (loginWindow != null)
    {
      loginWindow.webContents.send("invalid-code", errorStatus);
    }

  });

});

ipcMain.on("info-preview-logout", (e:Event) => {
  e.preventDefault();

  axios({
    method: "post",
    url: `${urlWp}/info-preview-logout`,
    data: { InfoPreviewAccessId: allData.openInfoPreview.infoPreviewAccessId, ReportId: allData.reportId },
    headers: { Authorization: `Bearer ${allData.token}` }
  }).then((res:AxiosResponse) => {

    if (res.data.isLogoutDone === true) {

      if (previewWindow != null)
      {
        closeFlag.isWindowAppCloseBtnClicked = false;
        previewWindow.close();
      }
    }    

  }).catch((error:AxiosError) => {

    console.log("Error message: ", error.message);

  });

});

ipcMain.on("open-writing-window", (e:Event) => {
  e.preventDefault();

  axios({
    method: "post",
    url: `${urlWp}/writing-window`,
    data: { 
      StudentId:allData.student.id,
      Code:allData.question.code, 
      InfoPreviewAccessLoginAt: allData.openInfoPreview.inforPreviewAccessLoginAt,
      QuestionId:allData.question.id,
      ReportId: allData.reportId
    },
    headers: { Authorization: `Bearer ${allData.token}` }
  }).then((res:AxiosResponse) => {

    allData.answerId = res.data.answerId;
    allData.answerBody = res.data.answerBody;
    allData.answerStartAt = res.data.answerStartAt;
    allData.writingWindowAccessId = res.data.writingWindowAccessId;

    const allDataForWritingWindow:IAllDataForWritingWindow = {
      answerStartAt:res.data.answerStartAt,
      answerBody:res.data.answerBody,
      studentName:allData.student.name,
      email:allData.student.email,
      school:allData.student.school,
      code:allData.question.code,
      subject:allData.question.subject,
      questionBody:allData.question.questionBody,
      allocatedTime:allData.question.allocatedTime,
      teacherName:allData.question.teacherName,
    }

    // console.log("Data for Writing Window: ", allDataForWritingWindow);

    createWritingWindow();
  
    if (writingWindow != null)
    {
      writingWindow.webContents.on("did-finish-load", ()=>{
        writingWindow?.webContents.send("open-writing-window", allDataForWritingWindow)
      });

      // console.log("Data for Writing Window: ", allDataForWritingWindow);
    }

    if (previewWindow != null)
    {
      previewWindow.close();
    }

  }).catch((error:AxiosError) => {

    console.log("Error message: ", error.message);

  });


});

ipcMain.on("writing-window-logout", (e:Event, AnswerBody:string) => {
  e.preventDefault();

  allData.answerBody = AnswerBody;

  axios({
    method: "post",
    url: `${urlWp}/writing-window-logout`,
    data: { 
      AnswerId:allData.answerId,
      WritingWindowAccessId:allData.writingWindowAccessId,
      ReportId:allData.reportId,
      StudentId:allData.student.id,
      Code:allData.question.code, 
      AnswerBody:AnswerBody,
    },
    headers: { Authorization: `Bearer ${allData.token}` }
  }).then((res:AxiosResponse) => {

    if (res.data.isLogoutDone === true) {

      if (writingWindow != null)
      {
        closeFlag.isWindowAppCloseBtnClicked = false;
        writingWindow.close();
      }
    }  

  }).catch((error:AxiosError) => {

    console.log("Error message: ", error.message);

  });

});

ipcMain.on("time-out-logout", (e:Event, AnswerBody:string) => {
  e.preventDefault();

  allData.answerBody = AnswerBody;

  axios({
    method: "post",
    url: `${urlWp}/time-out-logout`,
    data: { 
      AnswerId:allData.answerId,
      WritingWindowAccessId:allData.writingWindowAccessId,
      ReportId:allData.reportId,
      StudentId:allData.student.id,
      Code:allData.question.code, 
      AnswerBody:AnswerBody,
    },
    headers: { Authorization: `Bearer ${allData.token}` }
  }).then((res:AxiosResponse) => {

    if (res.data.isLogoutDone === true) {

      if (writingWindow != null)
      {
        closeFlag.isWindowAppCloseBtnClicked = false;
        writingWindow.close();
      }
    }  

  }).catch((error:AxiosError) => {

    console.log("Error message: ", error.message);

  });

});

app.on("window-all-closed", function () {
  if (!isMac) app.quit();
})
