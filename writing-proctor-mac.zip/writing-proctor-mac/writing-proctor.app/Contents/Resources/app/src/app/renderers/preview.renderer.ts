window.addEventListener('DOMContentLoaded', () => {

    const nameSpan = document.getElementById('name') as HTMLSpanElement;
    const emailSpan = document.getElementById('email') as HTMLSpanElement;
    const schoolSpan = document.getElementById('school') as HTMLSpanElement;
    const codeSpan = document.getElementById('code') as HTMLSpanElement;
    const instructorSpan = document.getElementById('instructor') as HTMLSpanElement;
    const allocatedTimeSpan = document.getElementById('allocatedTime') as HTMLSpanElement;
    const infoPreviewLogoutBtn = document.getElementById("infoPreviewLogoutBtn") as HTMLButtonElement;
    const nextBtn = document.getElementById("nextBtn") as HTMLButtonElement;

    window.Preload.receiveLoginSuccessfulResponse((e:Event, allData:IAllDataForPreview) => {

        nameSpan.style.fontWeight = "bold";
        nameSpan.innerText = allData.studentName;
        
        emailSpan.style.fontWeight = "bold";
        emailSpan.innerText = allData.email;
        
        schoolSpan.style.fontWeight = "bold";
        schoolSpan.innerText = allData.school;
        
        codeSpan.style.fontWeight = "bold";
        codeSpan.innerText = allData.code;
        
        instructorSpan.style.fontWeight = "bold";
        instructorSpan.innerText = allData.teacherName;
        
        allocatedTimeSpan.style.fontWeight = "bold";
        allocatedTimeSpan.innerText = String(allData.allocatedTime) + " minutes";
        
        infoPreviewLogoutBtn.addEventListener("click", (e:Event) => {
            e.preventDefault();

            window.Preload.logoutInfoPreview();
        })

        // close window === logout
        window.addEventListener('beforeunload', (e:Event) => {
            e.preventDefault();
        });
        
        nextBtn.addEventListener("click", (e:Event) => {
            e.preventDefault();

            window.Preload.openWritingWindow();

        });

    });
});
