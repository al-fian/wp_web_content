import {ipcRenderer, contextBridge} from "electron";

contextBridge.exposeInMainWorld('Preload', {
        login: (loginInput:ILoginInput) => ipcRenderer.send("login-to-preview", loginInput),
        receiveLoginErrorResponse: (callback:ICallback) => {
                ipcRenderer.on("login-error", callback);
        },
        receiveLoginSuccessfulResponse: (callback:ICallback) => { 
                ipcRenderer.on("login-to-preview", callback);
        },
        verifyCode: (codeValue:string) => ipcRenderer.send('verify-code', codeValue),
        isCodeValid: (callback:ICallback) => {
                ipcRenderer.on('valid-code', callback)
        },
        isCodeInvalid: (callback:ICallback) => {
                ipcRenderer.on('invalid-code', callback)
        },
        logoutInfoPreview: () => ipcRenderer.send("info-preview-logout"),
        openWritingWindow: () => ipcRenderer.send("open-writing-window"),
        receiveDataForWritingWindow: (callback:ICallback) => {
                ipcRenderer.on("open-writing-window", callback)
        },
        logoutWritingWindow: (AnswerBody:string) => ipcRenderer.send("writing-window-logout", AnswerBody),
        logoutTimeOut: (AnswerBody:string) => ipcRenderer.send("time-out-logout", AnswerBody)
}); 
