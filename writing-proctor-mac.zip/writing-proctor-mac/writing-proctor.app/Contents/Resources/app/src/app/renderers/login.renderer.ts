window.addEventListener('DOMContentLoaded', () => {
    let emailValue:string = "";
    let passwordValue:string = "";
    let codeValue:string = "";

    const notificationParagraph = document.getElementById('notification') as HTMLParagraphElement;
    const beforeLoginBtnSpacer = document.getElementById('spacer-before-login-button') as HTMLParagraphElement;
    const emailInput = document.getElementById('email') as HTMLInputElement;
    const passwordInput = document.getElementById('password') as HTMLInputElement;
    const codeInput = document.getElementById('code') as HTMLInputElement;
    const submitLoginForm = document.getElementById('loginForm') as HTMLFormElement;
    const checkIcon = document.getElementById("checkIcon") as HTMLSpanElement;
    const closeIcon = document.getElementById("closeIcon") as HTMLSpanElement;
    const verifyCodeBtn = document.getElementById("verifyCode") as HTMLButtonElement;
    const cancelBtn = document.getElementById('cancelLogin') as HTMLButtonElement;

    emailInput.addEventListener('input', () => {
        
        emailValue = emailInput.value;

        if (!validateEmail(emailValue)) {
            notificationParagraph.textContent = "Email address must be valid.";
            notificationParagraph.classList.add("pink-text", "text-pink-darken-2", "vspacer-10");
            beforeLoginBtnSpacer.classList.remove("vspacer-15");
        } else {
            notificationParagraph.textContent = "";
            notificationParagraph.classList.remove("pink-text", "text-pink-darken-2", "vspacer-10"); 
            beforeLoginBtnSpacer.classList.add("vspacer-15");
        }
        
    });   

    passwordInput.addEventListener('input', () => {
        
        passwordValue = passwordInput.value
        if (!validatePassword(passwordValue)) {
            notificationParagraph.textContent = "Password must be between 6 and 20 characters, with one number and one uppercase letter.";
            notificationParagraph.classList.add("pink-text", "text-pink-darken-2", "vspacer-5");
            beforeLoginBtnSpacer.classList.remove("vspacer-15");
        } else {
            notificationParagraph.textContent = "";
            notificationParagraph.classList.remove("pink-text", "text-pink-darken-2", "vspacer-5"); 
            beforeLoginBtnSpacer.classList.add("vspacer-15");
        }
        
    });

    codeInput.addEventListener('input', () => {

        if (checkIcon.classList.contains("hide") === false)
        {
            checkIcon.classList.add("hide");
        }

        if (closeIcon.classList.contains("hide") === false)
        {
            closeIcon.classList.add("hide");
        }
 
        codeValue = codeInput.value.toUpperCase();
        codeInput.value = codeValue.toUpperCase();

        if (codeValue.length != 5) {
            notificationParagraph.textContent = "Code must be exactly 5 characters.";
            notificationParagraph.classList.add("pink-text", "text-pink-darken-2", "vspacer-10");
            beforeLoginBtnSpacer.classList.remove("vspacer-15");
        } else {
            notificationParagraph.textContent = "";
            notificationParagraph.classList.remove("pink-text", "text-pink-darken-2", "vspacer-10"); 
            beforeLoginBtnSpacer.classList.add("vspacer-15");
        }

    });
    
    submitLoginForm.addEventListener('submit', (e:Event) => {
        e.preventDefault();

        if (emailValue != null && passwordValue != null && codeValue != null) 
        {
            
            const loginInputData:ILoginInput = {
                email: emailValue,
                password: passwordValue,
                code: codeValue
            };

            window.Preload.login(loginInputData);

        }

    });
    
    verifyCodeBtn.addEventListener("click", (e:Event) => {
        e.preventDefault();

        if (codeValue != null) 
        {
            window.Preload.verifyCode(codeValue);
        }

        window.Preload.isCodeValid((e:Event, successStatus:number) => {

            if (successStatus === 200)
            {
                verifyCodeBtn.disabled = true;
                codeInput.disabled = true;
                verifyCodeBtn.textContent = "Valid";
                checkIcon.classList.remove("hide");
            }

        });

        window.Preload.isCodeInvalid((e:Event, errorStatus:number | undefined) => {

            if (errorStatus === 404)
            {
                closeIcon.classList.remove("hide");
            }

        });

    });
    
    cancelBtn.addEventListener('click', () => {

        if (emailValue.length > 0){
            emailInput.value = "";
        }

        if (passwordValue.length > 0){
            passwordInput.value = "";
        }

        if (codeValue.length > 0) {
            codeInput.value = "";
        }

        if (verifyCodeBtn.disabled === true)
        {
            verifyCodeBtn.disabled = false;
            codeInput.disabled = false;
            verifyCodeBtn.textContent = "Verify?";
        }

        if (checkIcon.classList.contains('hide') === false)
        {
            checkIcon.classList.add("hide");
        }

        if (closeIcon.classList.contains('hide') === false)
        {
            closeIcon.classList.add("hide");
        }

        if (notificationParagraph.innerText.length > 0)
        {
            notificationParagraph.innerText = "";
        }

    });

    window.Preload.receiveLoginErrorResponse((e:Event, errorStatus:number | undefined) => {

        if (errorStatus === 400 || 401 || 404){
            notificationParagraph.textContent = "Login failed. Input was invalid.";
            notificationParagraph.classList.add("pink-text", "text-pink-darken-2", "vspacer-10");
            beforeLoginBtnSpacer.classList.remove("vspacer-15");
        } else {
            notificationParagraph.textContent = "";
            notificationParagraph.classList.remove("pink-text", "text-pink-darken-2", "vspacer-10"); 
            beforeLoginBtnSpacer.classList.add("vspacer-15");
        }

    });

    const updateOnlineStatus = () => {
        if (!navigator.onLine){
            notificationParagraph.innerText = "You are offline!";
            notificationParagraph.classList.add("center-align","pink-text", "text-pink-darken-2", "vspacer-10");
            beforeLoginBtnSpacer.classList.remove("vspacer-15");
        } 
        
        if (navigator.onLine){
            notificationParagraph.textContent = "";
            notificationParagraph.classList.remove("center-align", "pink-text", "text-pink-darken-2", "vspacer-10"); 
            beforeLoginBtnSpacer.classList.add("vspacer-15");
        }
    }

    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);

    updateOnlineStatus();

}); // DOMContentLoaded

function validateEmail(email:string) {
    const res = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return res.test(String(email).toLowerCase());
}

function validatePassword(password:string) 
{ 
    const res = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
    return res.test(String(password));
}
