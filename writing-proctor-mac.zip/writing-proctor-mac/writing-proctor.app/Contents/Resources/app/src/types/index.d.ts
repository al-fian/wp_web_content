export declare global {

  interface Window {
    Preload: any;
    Countable:any;
    stored: Selection | null;
  }

  interface IQuestion {
    id: string;
    code: string;
    subject: string;
    questionBody: string;
    allocatedTime: number;
    teacherName: string;
  }

  interface IStudent {
    id: string;
    name: string;
    email: string;
    school: string;
  }

  interface IOpenInfoPreview
  {
    infoPreviewAccessId: string;
    inforPreviewAccessLoginAt: Date
  }

  interface ILoginResponse {
    isLoginSuccessful: boolean;
    message: string;
    token: string;
    student: IStudent;
    question: IQuestion;
    openInfoPreview: IOpenInfoPreview;
    report: IReport;
  }

  interface IAllData {
    token: string;
    student: IStudent;
    question: IQuestion;
    openInfoPreview: IOpenInfoPreview;
    reportId:string;
    writingWindowAccessId:string;
    answerStartAt:Date;
    answerBody:string;
    answerId:string;
  }

  interface IAllDataForPreview {
    studentName: string;
    email: string;
    school: string;
    code: string;
    allocatedTime: number;
    teacherName: string;
  }

  interface IAllDataForWritingWindow {
    answerStartAt:Date;
    answerBody:string;
    studentName: string;
    email: string;
    school: string;
    code: string;
    subject: string;
    questionBody: string;
    allocatedTime: number;
    teacherName: string;
  }

  interface ILoginInput {
    email: string;
    password: string;
    code: string;
  }

  interface ICallback {
    (event: Electron.IpcRendererEvent, ...args: any[]):void;
  }

  interface ICode {
    code:string;
  }

  interface ICloseFlag
  {
    isWindowAppCloseBtnClicked:boolean;
  }

  interface ITextCount {
    wordTotal:number;
    sentenceTotal:number;
    paragraphTotal:number;
  }

  interface ITextStore {
    copied:string;
    undo:string;
    redo:string;
    selectionStart:number;
    selectionEnd:number;
  }

  interface IErrorResponse {
    statusCode:number;
    errorMessage:string;
  }

}
